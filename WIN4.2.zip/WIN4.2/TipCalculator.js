function calculateTip() {
    var bill= document.getElementById("billamount").value;
    var service = document.getElementById("serviceQuality").value;
    var numOfPeople = document.getElementById("peopleamount").value;

// Make sure input is entered- if not give error message
if (bill === "" || service == 0) {
    alert("Enter values, and try again");
    return;
  }
  // Checking to see how many people are paying- if more than 1 is paying it will display the word "each"
  if (numOfPeople === "" || numOfPeople <= 1) {
    numOfPeople = 1;
    document.getElementById("each").style.display = "none";
  } else {
    document.getElementById("each").style.display = "block";
  }

 //Calculate tip
 var total = (bill * service) / numOfPeople;
 //round to two decimal places
 total = Math.round(total * 100) / 100;
 //next line allows us to always have two digits after decimal point
 total = total.toFixed(2);
 //Display the tip
 document.getElementById("TipTotal").style.display = "block";
 document.getElementById("tip").innerHTML = total;

}

//Hide the tip amount on load
document.getElementById("TipTotal").style.display = "none";
document.getElementById("each").style.display = "none";

//click to call function
document.getElementById("calculate").onclick = function() {
  calculateTip();

};
